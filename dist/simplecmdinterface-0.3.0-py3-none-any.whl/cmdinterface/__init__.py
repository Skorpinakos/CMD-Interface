# cmdinterface/__init__.py
from .CmdInterface import CmdInterface